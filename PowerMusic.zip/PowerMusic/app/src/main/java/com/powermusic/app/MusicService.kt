package com.powermusic.app

import android.app.*
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.audiofx.Equalizer
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class MusicService : Service() {

    private val binder = MusicBinder()
    var mediaPlayer: MediaPlayer? = null
    var equalizer: Equalizer? = null

    var songs: List<Song> = emptyList()
    var currentIndex: Int = 0
    var isShuffleOn = false
    var repeatMode = 0 // 0=off, 1=all, 2=one

    private val CHANNEL_ID = "PowerMusicChannel"
    private val NOTIF_ID = 1

    inner class MusicBinder : Binder() {
        fun getService(): MusicService = this@MusicService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    fun playSong(index: Int) {
        if (songs.isEmpty()) return
        currentIndex = index
        val song = songs[index]

        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            setDataSource(applicationContext, song.uri)
            prepare()
            start()
            setOnCompletionListener { playNext() }
        }

        // Init equalizer
        equalizer?.release()
        equalizer = Equalizer(0, mediaPlayer!!.audioSessionId).apply {
            enabled = true
        }

        startForeground(NOTIF_ID, buildNotification(song))
    }

    fun playNext() {
        if (songs.isEmpty()) return
        when {
            repeatMode == 2 -> playSong(currentIndex)
            isShuffleOn -> playSong((0 until songs.size).random())
            currentIndex < songs.size - 1 -> playSong(currentIndex + 1)
            repeatMode == 1 -> playSong(0)
            else -> { mediaPlayer?.pause() }
        }
    }

    fun playPrev() {
        if (songs.isEmpty()) return
        val prevIndex = if (currentIndex > 0) currentIndex - 1 else songs.size - 1
        playSong(prevIndex)
    }

    fun togglePlayPause() {
        mediaPlayer?.let {
            if (it.isPlaying) it.pause() else it.start()
        }
    }

    fun isPlaying() = mediaPlayer?.isPlaying ?: false

    fun getCurrentPosition() = mediaPlayer?.currentPosition ?: 0

    fun getDuration() = mediaPlayer?.duration ?: 0

    fun seekTo(pos: Int) { mediaPlayer?.seekTo(pos) }

    fun setEqualizerBand(band: Short, level: Short) {
        equalizer?.setBandLevel(band, level)
    }

    fun getBandLevelRange() = equalizer?.bandLevelRange ?: shortArrayOf(-1500, 1500)

    fun getNumberOfBands() = equalizer?.numberOfBands ?: 5

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "PowerMusic Player",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Music playback controls" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(song: Song): Notification {
        val intent = Intent(this, PlayerActivity::class.java)
        val pi = PendingIntent.getActivity(this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(song.title)
            .setContentText(song.artist)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        equalizer?.release()
        mediaPlayer?.release()
        super.onDestroy()
    }
}
