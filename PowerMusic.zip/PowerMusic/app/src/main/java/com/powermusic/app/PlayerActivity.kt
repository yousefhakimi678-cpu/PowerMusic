package com.powermusic.app

import android.content.*
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class PlayerActivity : AppCompatActivity() {

    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvCurrentTime: TextView
    private lateinit var tvTotalTime: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var btnPrev: ImageButton
    private lateinit var btnShuffle: ImageButton
    private lateinit var btnRepeat: ImageButton
    private lateinit var ivAlbumArt: ImageView
    private lateinit var eqContainer: LinearLayout

    private var musicService: MusicService? = null
    private var isBound = false
    private val handler = Handler(Looper.getMainLooper())

    private val updateRunnable = object : Runnable {
        override fun run() {
            musicService?.let {
                val pos = it.getCurrentPosition()
                val dur = it.getDuration()
                seekBar.progress = if (dur > 0) (pos * 100 / dur) else 0
                tvCurrentTime.text = formatTime(pos)
                tvTotalTime.text = formatTime(dur)
                btnPlayPause.setImageResource(
                    if (it.isPlaying()) android.R.drawable.ic_media_pause
                    else android.R.drawable.ic_media_play
                )
            }
            handler.postDelayed(this, 500)
        }
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            musicService = (binder as MusicService.MusicBinder).getService()
            isBound = true
            updateUI()
            buildEqualizer()
            handler.post(updateRunnable)
        }
        override fun onServiceDisconnected(name: ComponentName?) { isBound = false }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        tvTitle = findViewById(R.id.tvTitle)
        tvArtist = findViewById(R.id.tvArtist)
        tvCurrentTime = findViewById(R.id.tvCurrentTime)
        tvTotalTime = findViewById(R.id.tvTotalTime)
        seekBar = findViewById(R.id.seekBar)
        btnPlayPause = findViewById(R.id.btnPlayPause)
        btnNext = findViewById(R.id.btnNext)
        btnPrev = findViewById(R.id.btnPrev)
        btnShuffle = findViewById(R.id.btnShuffle)
        btnRepeat = findViewById(R.id.btnRepeat)
        ivAlbumArt = findViewById(R.id.ivAlbumArt)
        eqContainer = findViewById(R.id.eqContainer)

        setupControls()

        val intent = Intent(this, MusicService::class.java)
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun setupControls() {
        btnPlayPause.setOnClickListener {
            musicService?.togglePlayPause()
        }

        btnNext.setOnClickListener {
            musicService?.playNext()
            handler.postDelayed({ updateUI() }, 300)
        }

        btnPrev.setOnClickListener {
            musicService?.playPrev()
            handler.postDelayed({ updateUI() }, 300)
        }

        btnShuffle.setOnClickListener {
            musicService?.let {
                it.isShuffleOn = !it.isShuffleOn
                btnShuffle.alpha = if (it.isShuffleOn) 1.0f else 0.4f
            }
        }

        btnRepeat.setOnClickListener {
            musicService?.let {
                it.repeatMode = (it.repeatMode + 1) % 3
                btnRepeat.alpha = if (it.repeatMode > 0) 1.0f else 0.4f
            }
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val dur = musicService?.getDuration() ?: 0
                    musicService?.seekTo(progress * dur / 100)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun updateUI() {
        val service = musicService ?: return
        if (service.songs.isEmpty()) return
        val song = service.songs[service.currentIndex]
        tvTitle.text = song.title
        tvArtist.text = song.artist
        if (song.albumArtUri != null) {
            try { ivAlbumArt.setImageURI(song.albumArtUri) }
            catch (e: Exception) { ivAlbumArt.setImageResource(R.drawable.ic_music_note) }
        } else {
            ivAlbumArt.setImageResource(R.drawable.ic_music_note)
        }
    }

    private fun buildEqualizer() {
        val service = musicService ?: return
        val eq = service.equalizer ?: return
        eqContainer.removeAllViews()

        val bandNames = arrayOf("60Hz", "230Hz", "910Hz", "3.6kHz", "14kHz")
        val range = eq.bandLevelRange
        val min = range[0].toInt()
        val max = range[1].toInt()

        for (i in 0 until eq.numberOfBands) {
            val bandLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setPadding(8, 0, 8, 0)
            }

            val label = TextView(this).apply {
                text = if (i < bandNames.size) bandNames[i] else "Band $i"
                textSize = 10f
                setTextColor(getColor(R.color.accent))
                textAlignment = TextView.TEXT_ALIGNMENT_CENTER
            }

            val seekBar = SeekBar(this).apply {
                this.min = min
                this.max = max
                progress = eq.getBandLevel(i.toShort()).toInt()
                rotation = -90f
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, 250
                ).also { it.gravity = android.view.Gravity.CENTER_HORIZONTAL }
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                        if (fromUser) service.setEqualizerBand(i.toShort(), p.toShort())
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }

            bandLayout.addView(seekBar)
            bandLayout.addView(label)
            eqContainer.addView(bandLayout)
        }
    }

    private fun formatTime(ms: Int): String {
        val min = (ms / 1000) / 60
        val sec = (ms / 1000) % 60
        return "%d:%02d".format(min, sec)
    }

    override fun onDestroy() {
        handler.removeCallbacks(updateRunnable)
        if (isBound) unbindService(serviceConnection)
        super.onDestroy()
    }
}
