package com.powermusic.app

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var tvSongCount: TextView
    private lateinit var btnNowPlaying: Button
    private lateinit var searchView: SearchView

    private var musicService: MusicService? = null
    private var isBound = false
    private var allSongs: List<Song> = emptyList()
    private var adapter: SongAdapter? = null

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            musicService = (binder as MusicService.MusicBinder).getService()
            isBound = true
            loadSongs()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        tvSongCount = findViewById(R.id.tvSongCount)
        btnNowPlaying = findViewById(R.id.btnNowPlaying)
        searchView = findViewById(R.id.searchView)

        recyclerView.layoutManager = LinearLayoutManager(this)

        btnNowPlaying.setOnClickListener {
            startActivity(Intent(this, PlayerActivity::class.java))
        }

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = false
            override fun onQueryTextChange(newText: String?): Boolean {
                filterSongs(newText ?: "")
                return true
            }
        })

        checkPermissionsAndBind()
    }

    private fun checkPermissionsAndBind() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            Manifest.permission.READ_MEDIA_AUDIO
        else
            Manifest.permission.READ_EXTERNAL_STORAGE

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            bindMusicService()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(permission), 100)
        }
    }

    private fun bindMusicService() {
        val intent = Intent(this, MusicService::class.java)
        startService(intent)
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            bindMusicService()
        } else {
            Toast.makeText(this, "إذن الوصول للموسيقى مرفوض", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadSongs() {
        allSongs = scanMusicFiles()
        musicService?.songs = allSongs
        tvSongCount.text = "${allSongs.size} أغنية"
        setupAdapter(allSongs)
    }

    private fun setupAdapter(songs: List<Song>) {
        adapter = SongAdapter(songs) { index ->
            val realIndex = allSongs.indexOf(songs[index])
            musicService?.playSong(realIndex)
            adapter?.setCurrentPlaying(index)
            startActivity(Intent(this, PlayerActivity::class.java))
        }
        recyclerView.adapter = adapter
    }

    private fun filterSongs(query: String) {
        val filtered = if (query.isEmpty()) allSongs
        else allSongs.filter {
            it.title.contains(query, ignoreCase = true) ||
            it.artist.contains(query, ignoreCase = true) ||
            it.album.contains(query, ignoreCase = true)
        }
        setupAdapter(filtered)
        tvSongCount.text = "${filtered.size} أغنية"
    }

    private fun scanMusicFiles(): List<Song> {
        val songs = mutableListOf<Song>()
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        val cursor: Cursor? = contentResolver.query(uri, projection, selection, null, sortOrder)
        cursor?.use {
            val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumIdCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)

            while (it.moveToNext()) {
                val id = it.getLong(idCol)
                val albumId = it.getLong(albumIdCol)
                val songUri = ContentUris.withAppendedId(uri, id)
                val albumArtUri = Uri.parse("content://media/external/audio/albumart/$albumId")

                songs.add(Song(
                    id = id,
                    title = it.getString(titleCol) ?: "Unknown",
                    artist = it.getString(artistCol) ?: "Unknown Artist",
                    album = it.getString(albumCol) ?: "Unknown Album",
                    duration = it.getLong(durationCol),
                    uri = songUri,
                    albumArtUri = albumArtUri
                ))
            }
        }
        return songs
    }

    override fun onDestroy() {
        if (isBound) unbindService(serviceConnection)
        super.onDestroy()
    }
}
