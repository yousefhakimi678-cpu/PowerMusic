package com.powermusic.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SongAdapter(
    private val songs: List<Song>,
    private val onSongClick: (Int) -> Unit
) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    private var currentPlayingIndex = -1

    inner class SongViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val albumArt: ImageView = view.findViewById(R.id.ivAlbumArt)
        val title: TextView = view.findViewById(R.id.tvSongTitle)
        val artist: TextView = view.findViewById(R.id.tvArtist)
        val duration: TextView = view.findViewById(R.id.tvDuration)
        val nowPlaying: ImageView = view.findViewById(R.id.ivNowPlaying)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_song, parent, false)
        return SongViewHolder(view)
    }

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        val song = songs[position]
        holder.title.text = song.title
        holder.artist.text = song.artist
        holder.duration.text = song.getDurationFormatted()

        if (song.albumArtUri != null) {
            try {
                holder.albumArt.setImageURI(song.albumArtUri)
            } catch (e: Exception) {
                holder.albumArt.setImageResource(R.drawable.ic_music_note)
            }
        } else {
            holder.albumArt.setImageResource(R.drawable.ic_music_note)
        }

        // Highlight currently playing song
        if (position == currentPlayingIndex) {
            holder.nowPlaying.visibility = View.VISIBLE
            holder.title.setTextColor(holder.itemView.context.getColor(R.color.accent))
        } else {
            holder.nowPlaying.visibility = View.GONE
            holder.title.setTextColor(holder.itemView.context.getColor(R.color.text_primary))
        }

        holder.itemView.setOnClickListener { onSongClick(position) }
    }

    override fun getItemCount() = songs.size

    fun setCurrentPlaying(index: Int) {
        val old = currentPlayingIndex
        currentPlayingIndex = index
        if (old >= 0) notifyItemChanged(old)
        if (index >= 0) notifyItemChanged(index)
    }
}
